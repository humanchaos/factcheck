// FAKTCHECK v3.0 - FIXED Background Service Worker
// FIXES: Correct model, removed broken tools, added extensive logging

const GEMINI_API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

// ✅ FIX #1: Use correct, stable model name
const DEFAULT_MODEL = 'gemini-2.5-flash-lite';

console.log('[FAKTCHECK BG] ====================================');
console.log('[FAKTCHECK BG] Service worker started');
console.log('[FAKTCHECK BG] Model:', DEFAULT_MODEL);
console.log('[FAKTCHECK BG] ====================================');

// Rate Limiter
const rateLimiter = {
    calls: [],
    maxCalls: 30,
    windowMs: 60000,

    canMakeCall() {
        const now = Date.now();
        this.calls = this.calls.filter(t => now - t < this.windowMs);
        if (this.calls.length >= this.maxCalls) {
            console.log('[FAKTCHECK BG] Rate limit hit!');
            return false;
        }
        this.calls.push(now);
        return true;
    },

    getRemainingCalls() {
        const now = Date.now();
        this.calls = this.calls.filter(t => now - t < this.windowMs);
        return Math.max(0, this.maxCalls - this.calls.length);
    }
};

// Claim Cache
const claimCache = new Map();

async function hashClaim(claim) {
    try {
        const normalized = claim.toLowerCase().trim().replace(/\s+/g, ' ');
        const encoder = new TextEncoder();
        const hashBuffer = await crypto.subtle.digest('SHA-256', encoder.encode(normalized));
        return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
    } catch {
        return claim.toLowerCase().slice(0, 50);
    }
}

async function getCached(claim) {
    try {
        const hash = await hashClaim(claim);
        const cached = claimCache.get(hash);
        if (cached && Date.now() - cached.ts < 3600000) {
            console.log('[FAKTCHECK BG] Cache HIT');
            return { ...cached.data, fromCache: true };
        }
    } catch (e) { }
    return null;
}

async function setCache(claim, data) {
    try {
        if (claimCache.size >= 500) {
            const first = claimCache.keys().next().value;
            if (first) claimCache.delete(first);
        }
        const hash = await hashClaim(claim);
        claimCache.set(hash, { data, ts: Date.now() });
    } catch (e) { }
}

// Sanitization
function sanitize(text, maxLen = 5000) {
    if (typeof text !== 'string') return '';
    return text.replace(/[\x00-\x1F\x7F]/g, '').slice(0, maxLen).trim();
}

function validateClaims(data) {
    if (!Array.isArray(data)) {
        console.log('[FAKTCHECK BG] validateClaims: Not an array:', typeof data);
        return [];
    }
    const valid = data.filter(item =>
        typeof item === 'object' && item !== null &&
        typeof item.claim === 'string' &&
        item.claim.length > 5
    ).map(item => ({
        claim: sanitize(item.claim, 1000),
        speaker: item.speaker ? String(item.speaker).slice(0, 100) : null,
        checkability: Number(item.checkability) || 3,
        importance: Number(item.importance) || 3,
        category: String(item.category || 'UNKNOWN')
    }));
    console.log('[FAKTCHECK BG] Validated claims:', valid.length);
    return valid;
}

function validateVerification(data) {
    const validVerdicts = ['true', 'mostly_true', 'partially_true', 'mostly_false', 'false', 'unverifiable', 'misleading', 'opinion'];
    if (typeof data !== 'object' || !data) {
        return { verdict: 'unverifiable', displayVerdict: 'unverifiable', confidence: 0, explanation: 'Invalid response', sources: [] };
    }
    const verdict = validVerdicts.includes(data.verdict) ? data.verdict : 'unverifiable';
    const displayMap = {
        'true': 'true', 'mostly_true': 'true',
        'false': 'false', 'mostly_false': 'false',
        'partially_true': 'partially_true', 'misleading': 'partially_true',
        'unverifiable': 'unverifiable', 'opinion': 'opinion'
    };
    return {
        verdict,
        displayVerdict: displayMap[verdict] || 'unverifiable',
        confidence: Math.max(0, Math.min(1, Number(data.confidence) || 0.5)),
        explanation: sanitize(String(data.explanation || ''), 500),
        key_facts: Array.isArray(data.key_facts) ? data.key_facts.filter(f => typeof f === 'string').slice(0, 5) : [],
        sources: Array.isArray(data.sources) ? data.sources.filter(s => s && s.url).slice(0, 5).map(s => ({
            title: String(s.title || 'Source').slice(0, 100),
            url: s.url,
            tier: 3
        })) : []
    };
}

// Language Detection
function detectLang(text) {
    const deWords = ['und', 'der', 'die', 'das', 'ist', 'nicht', 'mit', 'für', 'von', 'wir', 'haben', 'dass', 'werden', 'wurde', 'sind'];
    const words = text.toLowerCase().split(/\s+/);
    const deCount = words.filter(w => deWords.includes(w)).length;
    return deCount > words.length * 0.03 ? 'de' : 'en';
}

// ✅ FIX #2: Gemini API call with proper error handling and NO broken tools
async function callGemini(apiKey, prompt) {
    const url = `${GEMINI_API_BASE}/${DEFAULT_MODEL}:generateContent?key=${apiKey}`;

    console.log('[FAKTCHECK BG] ----------------------------------------');
    console.log('[FAKTCHECK BG] Calling Gemini API');
    console.log('[FAKTCHECK BG] URL:', url.replace(apiKey, 'API_KEY_HIDDEN'));
    console.log('[FAKTCHECK BG] Prompt length:', prompt.length);

    // ✅ FIX: Removed broken googleSearch tool that was causing errors
    const body = {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
            temperature: 0.1,
            maxOutputTokens: 4096
        }
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        console.log('[FAKTCHECK BG] Response status:', response.status);

        if (!response.ok) {
            const errorText = await response.text();
            console.error('[FAKTCHECK BG] HTTP Error:', response.status, errorText.slice(0, 200));
            throw new Error(`HTTP ${response.status}: ${errorText.slice(0, 100)}`);
        }

        const data = await response.json();

        if (data.error) {
            console.error('[FAKTCHECK BG] API Error:', JSON.stringify(data.error));
            throw new Error(data.error.message || 'Gemini API error');
        }

        const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';

        if (!text) {
            console.error('[FAKTCHECK BG] Empty response from API');
            console.error('[FAKTCHECK BG] Full response:', JSON.stringify(data).slice(0, 500));
            throw new Error('Empty response from Gemini API');
        }

        // Clean markdown
        const cleaned = text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();
        console.log('[FAKTCHECK BG] Response received, length:', cleaned.length);
        console.log('[FAKTCHECK BG] Response preview:', cleaned.slice(0, 100));

        return cleaned;
    } catch (error) {
        console.error('[FAKTCHECK BG] Fetch error:', error.message);
        throw error;
    }
}

// Extract Claims
async function extractClaims(text, apiKey) {
    const lang = detectLang(text);
    const sanitized = sanitize(text);

    console.log('[FAKTCHECK BG] ========== EXTRACT CLAIMS ==========');
    console.log('[FAKTCHECK BG] Language:', lang);
    console.log('[FAKTCHECK BG] Input text length:', sanitized.length);
    console.log('[FAKTCHECK BG] Text preview:', sanitized.slice(0, 100) + '...');

    if (sanitized.length < 50) {
        console.log('[FAKTCHECK BG] Text too short, skipping');
        return { claims: [], lang };
    }

    const prompt = lang === 'de' ?
        `Du bist ein Faktenchecker. Extrahiere überprüfbare Faktenbehauptungen aus diesem Transkript.

Text: "${sanitized.slice(0, 4000)}"

WICHTIGE REGELN:
1. Jede Behauptung MUSS semantisch vollständig sein (Subjekt + Prädikat + Objekt)
2. NIEMALS Satzfragmente wie "Das haben sie gemacht" oder "Er sagte das" extrahieren
3. Der Claim muss OHNE zusätzlichen Kontext verständlich und überprüfbar sein
4. Füge fehlenden Kontext aus dem Transkript hinzu, um die Behauptung vollständig zu machen
5. NUR Behauptungen mit konkreten Zahlen, Daten, Namen oder überprüfbaren Fakten

GUTE BEISPIELE:
✓ "Die Arbeitslosenquote in Deutschland sank 2023 auf 5,7%"
✓ "Tesla verkaufte 2023 über 1,8 Millionen Fahrzeuge weltweit"
✓ "Der Mindestlohn wurde im Oktober 2022 auf 12 Euro erhöht"

SCHLECHTE BEISPIELE (NICHT EXTRAHIEREN):
✗ "Das haben die Demokraten gemacht" (Was haben sie gemacht?)
✗ "Die Preise sind gesunken" (Welche Preise? Um wieviel?)
✗ "Er hat das gesagt" (Wer? Was gesagt?)
✗ "Das stimmt nicht" (Was stimmt nicht?)

Antworte NUR mit JSON-Array:
[{"claim": "Vollständige, selbsterklärende Behauptung mit allen Details", "speaker": "Name oder null", "checkability": 1-5, "importance": 1-5, "category": "STATISTIK|WIRTSCHAFT|POLITIK|WISSENSCHAFT"}]

Keine überprüfbaren Fakten? Antworte: []` :
        `You are a fact-checker. Extract verifiable factual claims from this transcript.

Text: "${sanitized.slice(0, 4000)}"

CRITICAL RULES:
1. Every claim MUST be semantically complete (Subject + Verb + Object)
2. NEVER extract sentence fragments like "They did that" or "He said this"
3. The claim must be understandable and verifiable WITHOUT additional context
4. Add missing context from the transcript to make the claim self-contained
5. ONLY claims with specific numbers, dates, names, or verifiable facts

GOOD EXAMPLES:
✓ "US unemployment rate fell to 3.7% in November 2023"
✓ "Tesla sold over 1.8 million vehicles worldwide in 2023"
✓ "The minimum wage was raised to $15 per hour in California in 2022"

BAD EXAMPLES (DO NOT EXTRACT):
✗ "Democrats did not do that" (Did not do what?)
✗ "Prices came down" (Which prices? By how much?)
✗ "He said that" (Who? Said what?)
✗ "That's not true" (What's not true?)

Respond ONLY with JSON array:
[{"claim": "Complete, self-explanatory claim with all details", "speaker": "Name or null", "checkability": 1-5, "importance": 1-5, "category": "STATISTICS|ECONOMY|POLITICS|SCIENCE"}]

No verifiable facts? Respond: []`;

    try {
        const result = await callGemini(apiKey, prompt);
        console.log('[FAKTCHECK BG] Raw API response:', result.slice(0, 300));

        let parsed;
        try {
            parsed = JSON.parse(result);
            console.log('[FAKTCHECK BG] JSON parsed successfully');
        } catch (parseError) {
            console.log('[FAKTCHECK BG] JSON parse failed, trying to extract array...');
            const match = result.match(/\[[\s\S]*\]/);
            if (match) {
                parsed = JSON.parse(match[0]);
                console.log('[FAKTCHECK BG] Array extracted successfully');
            } else {
                console.error('[FAKTCHECK BG] Could not find JSON array in response');
                return { claims: [], lang, error: 'Could not parse response' };
            }
        }

        const validated = validateClaims(parsed);
        console.log('[FAKTCHECK BG] ========== RESULT ==========');
        console.log('[FAKTCHECK BG] Extracted', validated.length, 'claims');
        validated.forEach((c, i) => console.log(`[FAKTCHECK BG]   ${i + 1}. ${c.claim.slice(0, 60)}...`));
        return { claims: validated, lang };
    } catch (error) {
        console.error('[FAKTCHECK BG] ========== ERROR ==========');
        console.error('[FAKTCHECK BG] Extract claims failed:', error.message);
        return { claims: [], lang, error: error.message };
    }
}

// Verify Claim
async function verifyClaim(claimText, apiKey, lang = 'de') {
    console.log('[FAKTCHECK BG] ========== VERIFY CLAIM ==========');
    console.log('[FAKTCHECK BG] Claim:', claimText.slice(0, 80) + '...');

    const cached = await getCached(claimText);
    if (cached) return cached;

    const sanitized = sanitize(claimText, 1000);

    const prompt = lang === 'de' ?
        `Verifiziere diese Behauptung: "${sanitized}"

Bewerte ob die Behauptung wahr, falsch oder nicht überprüfbar ist.

Antworte NUR mit JSON (KEIN Markdown):
{"verdict": "true", "confidence": 0.8, "explanation": "Kurze Erklärung", "key_facts": ["Fakt 1"], "sources": [{"title": "Quelle", "url": "https://example.com"}]}

Mögliche Verdicts: true, false, partially_true, unverifiable, opinion` :
        `Verify this claim: "${sanitized}"

Evaluate if the claim is true, false, or unverifiable.

Respond ONLY with JSON (NO markdown):
{"verdict": "true", "confidence": 0.8, "explanation": "Brief explanation", "key_facts": ["Fact 1"], "sources": [{"title": "Source", "url": "https://example.com"}]}

Possible verdicts: true, false, partially_true, unverifiable, opinion`;

    try {
        const result = await callGemini(apiKey, prompt);

        let parsed;
        try {
            parsed = JSON.parse(result);
        } catch {
            const match = result.match(/\{[\s\S]*\}/);
            parsed = match ? JSON.parse(match[0]) : { verdict: 'unverifiable' };
        }

        const validated = validateVerification(parsed);
        await setCache(claimText, validated);
        console.log('[FAKTCHECK BG] Verdict:', validated.verdict, '| Confidence:', validated.confidence);
        return validated;
    } catch (error) {
        console.error('[FAKTCHECK BG] Verify failed:', error.message);
        return {
            verdict: 'unverifiable',
            displayVerdict: 'unverifiable',
            confidence: 0,
            explanation: 'Fehler: ' + error.message,
            sources: [],
            error: error.message
        };
    }
}

// Message Handler
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[FAKTCHECK BG] Message received:', message.type);

    if (message.type === 'EXTRACT_CLAIMS') {
        if (!rateLimiter.canMakeCall()) {
            console.log('[FAKTCHECK BG] Rate limited, rejecting');
            sendResponse({ error: 'Rate limit exceeded. Please wait a moment.', claims: [] });
            return true;
        }

        (async () => {
            try {
                const { geminiApiKey } = await chrome.storage.local.get(['geminiApiKey']);
                if (!geminiApiKey) {
                    console.error('[FAKTCHECK BG] No API key configured!');
                    sendResponse({ error: 'No API key. Click extension icon to add your Gemini API key.', claims: [] });
                    return;
                }
                console.log('[FAKTCHECK BG] API key found, length:', geminiApiKey.length);

                const result = await extractClaims(message.text, geminiApiKey);
                console.log('[FAKTCHECK BG] Sending response:', result.claims?.length || 0, 'claims');
                sendResponse(result);
            } catch (e) {
                console.error('[FAKTCHECK BG] Handler error:', e);
                sendResponse({ error: e.message, claims: [] });
            }
        })();
        return true;
    }

    if (message.type === 'VERIFY_CLAIM') {
        if (!rateLimiter.canMakeCall()) {
            sendResponse({ error: 'Rate limit', verification: null });
            return true;
        }

        (async () => {
            try {
                const { geminiApiKey } = await chrome.storage.local.get(['geminiApiKey']);
                if (!geminiApiKey) {
                    sendResponse({ error: 'No API key', verification: null });
                    return;
                }
                const verification = await verifyClaim(message.claim, geminiApiKey, message.lang || 'de');
                sendResponse({ verification });
            } catch (e) {
                console.error('[FAKTCHECK BG] Verify handler error:', e);
                sendResponse({ error: e.message, verification: null });
            }
        })();
        return true;
    }

    if (message.type === 'CHECK_API_KEY') {
        chrome.storage.local.get(['geminiApiKey'], (result) => {
            const hasKey = !!result.geminiApiKey;
            console.log('[FAKTCHECK BG] API key check:', hasKey ? 'PRESENT' : 'MISSING');
            sendResponse({ hasKey });
        });
        return true;
    }

    if (message.type === 'SAVE_API_KEY') {
        chrome.storage.local.set({ geminiApiKey: message.apiKey }, () => {
            console.log('[FAKTCHECK BG] API key saved successfully');
            sendResponse({ success: true });
        });
        return true;
    }

    if (message.type === 'GET_STATS') {
        sendResponse({
            cacheSize: claimCache.size,
            remaining: rateLimiter.getRemainingCalls()
        });
        return true;
    }

    return false;
});

console.log('[FAKTCHECK BG] Ready and listening for messages');
